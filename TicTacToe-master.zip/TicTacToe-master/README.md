# TicTacToe
A simple Tic Tac Toe game for Android written in Java

* 5x5 Grid Support
* Works Offline only for now

## Screenshots

<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/97c4691d-1c21-44e4-9c5e-75c8deb5e9f0" height=300>
<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/a94729f1-6b83-4a43-a6d4-e31cdeeb1463" height=300>
<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/ba780a0b-cd9b-4c85-a308-0d5e3390cf4c" height=300>
<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/fa7fbf29-e3cc-436e-84f4-0c190a2b8e6d" height=300>
<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/47d34c74-66ef-43e1-8df5-c78cd60c9fa7" height=300>
<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/e276f38b-c2de-4b7a-a4e8-1d667f574cea" height=300>
<img src="https://github.com/tusharvidhani3/TicTacToe/assets/89744210/fd469b1f-042e-4f8d-ad4e-1291a3ad3eda" height=300>
